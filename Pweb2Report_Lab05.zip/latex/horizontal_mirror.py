def horizontalMirror(self):
    return Picture(self.img[::-1])
